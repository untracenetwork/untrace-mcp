# @untracenetwork/sdk

The core Untrace client for any server runtime (Node 20+, Bun, Deno, Workers). It holds your client secret, lists, downloads and uploads files the key is a member of, and manages members.

```bash
npm i @untracenetwork/sdk
```

```ts
import { UntraceClient } from "@untracenetwork/sdk"

const untrace = new UntraceClient() // reads UNTRACE_CLIENT_ID and UNTRACE_CLIENT_SECRET
const { files } = await untrace.files.list()
const file = await untrace.files.download(files[0].fileId)
```

Version 1.0.0. Full guide, security model and API reference:
https://github.com/untracenetwork/untrace-sdk#readme

Self-hosting Drive: https://github.com/untracenetwork/untrace-cli/blob/main/docs/SELF-HOST.md

License: MIT
